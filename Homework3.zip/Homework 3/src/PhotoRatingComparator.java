
/**
 * Homework 3 Andre Tan, akt6pfg
 */

import java.util.Comparator;

public class PhotoRatingComparator implements Comparator<Photo> {

    /**
     * Compares two photos, first by rating and then by caption if needed. If the first photo comes first it returns a
     * negative integer, if the second photo comes first it returns a positive integer, and if they are equal, return zero.
     * 
     * @param p1 The first photo object
     * @param p2 The second photo object
     * @return A negative int if the first photo comes first, a positive int if the second photo comes first, and zero if
     *         they are equal
     */
    public int compare(Photo p1, Photo p2) {
        int retVal = p2.getRating() - p1.getRating();
        if (retVal != 0) {
            return retVal;
        }
        return p1.getCaption().compareTo(p2.getCaption());
    }

}
