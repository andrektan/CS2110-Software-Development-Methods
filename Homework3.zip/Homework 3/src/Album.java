import java.util.ArrayList;

/**
 * Homework 3 Andre Tan, akt6pfg
 */

public class Album extends PhotoContainer {
    /**
     * Assigns a name to a new album and creates an empty ArrayList of photos
     * 
     * @param name The String name to be given to the new album
     */
    public Album(String name) {
        super(name);
        this.photos = new ArrayList<Photo>();
    }
}
