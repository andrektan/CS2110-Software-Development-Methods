
/**
 * Homework 3 Andre Tan, akt6pfg
 */

import java.util.ArrayList;
import java.util.HashSet;

public class Library extends PhotoContainer {

    /**
     * Holds the id of the library as an integer
     */
    private final int id;

    /**
     * Holds the set of albums in a HashSet
     */
    private HashSet<Album> albums;

    /**
     * Assigns a name and id to a new library
     * 
     * @param nameInput The name to be assigned to the library
     * @param idInput   The id to be assigned to the library
     */
    public Library(String nameInput, int idInput) {
        super(nameInput);
        this.id = idInput;
        this.albums = new HashSet<Album>();
    }

    /**
     * Getter for the id of the library
     * 
     * @return The integer id of the library
     */
    public int getId() {
        return this.id;
    }

    /**
     * Getter for the set of albums
     * 
     * @return The HashSet of albums
     */
    public HashSet<Album> getAlbums() {
        return this.albums;
    }

    /**
     * Deletes a photo from a library if it contains it, as well as from all albums
     * 
     * @param p The photo to be deleted from the library and albums
     * @return True if the photo was removed, and false if the library did not contain it
     */
    public boolean removePhoto(Photo p) {
        if ((this.photos).contains(p)) {
            (this.photos).remove(p);
            for (Album a : albums) {
                a.removePhoto(p);
            }
            return true;
        } else
            return false;
    }

    /**
     * Compares the id of two libraries and returns true if they are the same
     * 
     * @param o The library that is the passing object to be compared to the casting one
     * @return True if the two libraries have the same id, and false if not
     */
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (o instanceof Library) {
            Library other = (Library) o;
            return (this.id == other.id);
        } else {
            return false;
        }
    }

    /**
     * Converts a library into a string listing its name, id, and photos
     * 
     * @return The name, id, and photos of the library
     */
    public String toString() {
        return ("Name: " + this.name + ", Id: " + this.id + ", Photos: " + this.photos + "Albums: " + this.albums);
    }

    /**
     * Takes two libraries and returns an ArrayList with photos found in both libraries
     * 
     * @param a The first library of photos
     * @param b The second library of photos
     * @return An ArrayList containing photos found in both libraries
     */
    public static ArrayList<Photo> commonPhotos(Library a, Library b) {
        ArrayList<Photo> combinedList = new ArrayList<Photo>();
        for (int i = 0; i < a.photos.size(); i++) {
            if ((!combinedList.contains(a.photos.get(i))) && (b.photos.contains(a.photos.get(i)))) {
                combinedList.add(a.photos.get(i));
            }
        }
        for (int i = 0; i < b.photos.size(); i++) {
            if ((!combinedList.contains(b.photos.get(i))) && (a.photos.contains(b.photos.get(i)))) {
                combinedList.add(b.photos.get(i));
            }
        }
        return combinedList;
    }

    /**
     * Takes two libraries and returns a value between 0.0 and 1.0 based on how many photos they share
     * 
     * @param a The first library of photos
     * @param b The second library of photos
     * @return A value between 0.0 and 1.0 measuring similarity between the libraries
     */
    public static double similarity(Library a, Library b) {
        double num;
        if (a.photos.size() == 0 || b.photos.size() == 0) {
            return 0.0;
        }
        if (a.photos.size() <= b.photos.size()) {
            num = a.photos.size();
        } else {
            num = b.photos.size();
        }
        return ((commonPhotos(a, b).size()) / num);
    }

    /**
     * Creates a new album in the HashSet of albums if one with the input name does not already exist
     * 
     * @param albumName A String that the name of the new album will have
     * @return True if the album was successfully created, and false if one with the given name already existed
     */
    public boolean createAlbum(String albumName) {
        Album newAlbum = new Album(albumName);
        if (!this.albums.contains(newAlbum)) {
            this.albums.add(newAlbum);
            return true;
        } else
            return false;
    }

    /**
     * Removes an album from the HashSet of albums if it exists
     * 
     * @param albumName A String that is the name of the album to be removed
     * @return True if the album was successfully removed, and false if it was not in the HashSet
     */
    public boolean removeAlbum(String albumName) {
        for (Album a : this.albums) {
            if (a.getName().equals(albumName)) {
                return albums.remove(a);
            }
        }
        return false;
    }

    /**
     * Adds a photo to an album if it is in the Library's list of photos and is not already in that album
     * 
     * @param p         The photo to be added to the album
     * @param albumName The name of the album to add the photo to
     * @return True if the photo was successfully added, false if the album or photo did not exist or if the photo was
     *         already in the album
     */
    public boolean addPhotoToAlbum(Photo p, String albumName) {
        Album a = getAlbumByName(albumName);
        if (a == null) {
            return false;
        } else if ((this.photos).contains(p)) {
            a.addPhoto(p);
            return true;
        }
        return false;
    }

    /**
     * Removes a photo from an album if it exists in that album
     * 
     * @param p         The photo to be removed from the alum
     * @param albumName The String name of the album the photo is to be removed from
     * @return True if the photo was successfully removed, false if the album or photo did not exist or if the photo was not
     *         in the album
     */
    public boolean removePhotoFromAlbum(Photo p, String albumName) {
        for (Album a : this.albums) {
            if (a.getName().equals(albumName)) {
                return a.removePhoto(p);
            }
        }
        return false;
    }

    /**
     * Returns an album given the String name of the album
     * 
     * @param albumName The String name of the album to be returned
     * @return The album if one with the given name exists, or null if no such album exists
     */
    private Album getAlbumByName(String albumName) {
        for (Album a : this.albums) {
            if (a.getName().equals(albumName)) {
                return a;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Photo p1 = new Photo("New Years", "no cap", "", 5);
        Photo p2 = new Photo("New", "cap", "2020-01-01", 4);
        Photo p3 = new Photo("College", "capper", "2020-02-24", 3);
        Photo p4 = new Photo("Wow", "ok", "2001-12-24", 2);
        Library l1 = new Library("UVA", 123);
        Library l2 = new Library("NY", 124);
        Library l3 = new Library("OK", 125);
        l1.addPhoto(p1);
        l1.addPhoto(p2);
        l1.addPhoto(p3);
        l1.addPhoto(p4);
        System.out.println(l1.hasPhoto(p4));
        System.out.println(l1.numPhotos());
        System.out.println(l1.removePhoto(p4));
        System.out.println(l1.hasPhoto(p4));
        System.out.println(l1.numPhotos());
        System.out.println(l1);
        l2.addPhoto(p1);
        l2.addPhoto(p3);
        l2.addPhoto(p4);
        System.out.println(l2.removePhoto(p2));
        System.out.println(l2);
        System.out.println(commonPhotos(l1, l2));
        System.out.println(similarity(l1, l2));
        System.out.println(commonPhotos(l1, l3));
        System.out.println(similarity(l1, l3));
        System.out.println(l1.equals(l2));
        System.out.println(l2.equals(l3));
        System.out.println(l1.getPhotos(3));
        System.out.println(l2.getPhotos(4));
    }

}
