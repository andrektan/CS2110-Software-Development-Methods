import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collections;

import org.junit.Test;

public class PhotoContainerTest {

    @Test
    // Test for removePhoto method where the photo exists in the library
    public void testRemovePhoto1() {
        // input
        Library l1 = new Library("l1", 1);
        Photo p1 = new Photo("Filename", "No caption.", "2001-12-24", 5);
        l1.addPhoto(p1);

        // expected
        boolean expected = true;

        // actual
        boolean actual = l1.removePhoto(p1);

        assertEquals("Photo was not changed as expected", expected, actual);
    }

    @Test
    // Test for removePhoto method where the photo does not exist in the library
    public void testRemovePhoto2() {
        // input
        Library l1 = new Library("l1", 1);
        Photo p1 = new Photo("Filename", "No caption.", "2001-12-24", 5);

        // expected
        boolean expected = false;

        // actual
        boolean actual = l1.removePhoto(p1);

        assertEquals("Photo was not changed as expected", expected, actual);
    }

    @Test
    // Test for compareTo method where the dates taken are different
    public void testCompareTo1() {
        // input
        Photo p1 = new Photo("Filename", "No caption.", "2001-12-24", 5);
        Photo p2 = new Photo("Filename", "A.", "2001-12-23", 5);

        // expected
        int expected = 1;

        // actual
        int actual = p1.compareTo(p2);

        assertEquals("Photos were not ordered correctly", expected, actual);
    }

    @Test
    // Test for compareTo method where the dates taken are the same and the captions are different
    public void testCompareTo2() {
        // input
        Photo p1 = new Photo("Filename", "A.", "2001-12-24", 5);
        Photo p2 = new Photo("Filename", "B.", "2001-12-24", 5);

        // expected
        int expected = -1;

        // actual
        int actual = p1.compareTo(p2);

        assertEquals("Photos were not ordered correctly", expected, actual);
    }

    @Test
    // Test for compare method in PhotoCaptionComparator where the captions are different
    public void testCompareCaptionComparator1() {
        // input
        Photo p1 = new Photo("Filename", "A.", "2001-12-24", 4);
        Photo p2 = new Photo("Filename", "B.", "2001-12-24", 5);

        // expected
        ArrayList<Photo> expected = new ArrayList<Photo>();
        expected.add(p1);
        expected.add(p2);

        // actual
        ArrayList<Photo> actual = new ArrayList<Photo>();
        actual.add(p2);
        actual.add(p1);
        Collections.sort(actual, new PhotoCaptionComparator());

        assertEquals("ArrayList not sorted correctly", expected, actual);
    }

    @Test
    // Test for compare method in PhotoCaptionComparator where the captions are the same and ratings are different
    public void testCompareCaptionComparator2() {
        // input
        Photo p1 = new Photo("Filename", "A.", "2001-12-24", 4);
        Photo p2 = new Photo("Filename", "A.", "2001-12-24", 5);

        // expected
        ArrayList<Photo> expected = new ArrayList<Photo>();
        expected.add(p1);
        expected.add(p2);

        // actual
        ArrayList<Photo> actual = new ArrayList<Photo>();
        actual.add(p2);
        actual.add(p1);
        Collections.sort(actual, new PhotoCaptionComparator());

        assertEquals("ArrayList not sorted correctly", expected, actual);
    }

    @Test
    // Test for compare method in PhotoRatingComparator where the ratings are different
    public void testCompareRatingComparator1() {
        // input
        Photo p1 = new Photo("Filename", "A.", "2001-12-24", 1);
        Photo p2 = new Photo("Filename", "A.", "2001-12-24", 5);

        // expected
        ArrayList<Photo> expected = new ArrayList<Photo>();
        expected.add(p2);
        expected.add(p1);

        // actual
        ArrayList<Photo> actual = new ArrayList<Photo>();
        actual.add(p1);
        actual.add(p2);
        Collections.sort(actual, new PhotoRatingComparator());

        assertEquals("ArrayList not sorted correctly", expected, actual);
    }

    @Test
    // Test for compare method in PhotoRatingComparator where the ratings are the same and the captions are different
    public void testCompareRatingComparator2() {
        // input
        Photo p1 = new Photo("Filename", "A.", "2001-12-24", 5);
        Photo p2 = new Photo("Filename", "B.", "2001-12-24", 5);

        // expected
        ArrayList<Photo> expected = new ArrayList<Photo>();
        expected.add(p1);
        expected.add(p2);

        // actual
        ArrayList<Photo> actual = new ArrayList<Photo>();
        actual.add(p2);
        actual.add(p1);
        Collections.sort(actual, new PhotoRatingComparator());

        assertEquals("ArrayList not sorted correctly", expected, actual);
    }
}
