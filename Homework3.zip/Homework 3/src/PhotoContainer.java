
/**
 * Homework 3 Andre Tan, akt6pfg
 */

import java.util.ArrayList;

public abstract class PhotoContainer {

    /**
     * Holds the name of the PhotoContainer as a String
     */
    protected String name;

    /**
     * Holds the photos contained in the PhotoContainer in an ArrayList
     */
    protected ArrayList<Photo> photos;

    /**
     * Assigns a name to a new PhotoContainer and creates an empty ArrayList of photos
     * 
     * @param name The String name to be given to the new PhotoContainer
     */
    public PhotoContainer(String name) {
        this.name = name;
        this.photos = new ArrayList<Photo>();
    }

    /**
     * Getter for the name of the PhotoContainer
     * 
     * @return The name of the PhotoContainer
     */
    public String getName() {
        return name;
    }

    /**
     * Setter to change the name of an PhotoContainer
     * 
     * @param name The new name to be assigned to the PhotoContainer
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for the ArrayList of photos in the PhotoContainer
     * 
     * @return The ArrayList of photos in the PhotoContainer
     */
    public ArrayList<Photo> getPhotos() {
        return photos;
    }

    /**
     * Adds a photo to the ArrayList of photos in the PhotoContainer
     * 
     * @param p The photo to be added to the PhotoContainer
     * @return True if the photo was successfully added, false if it was not or if the ArrayList already contained it
     */
    public boolean addPhoto(Photo p) {
        if (p == null) {
            return false;
        }
        if (!photos.contains(p)) {
            photos.add(p);
            return true;
        }
        return false;
    }

    /**
     * Checks if an PhotoContainer contains a given photo in its ArrayList of photos
     * 
     * @param p The photo to be checked for in the ArrayList of photos
     * @return True if the PhotoContainer contains the photo, and false if it does not
     */
    public boolean hasPhoto(Photo p) {
        if (photos.contains(p)) {
            return true;
        } else
            return false;
    }

    /**
     * Removes a photo from an PhotoContainer if it contains the photo
     * 
     * @param p The photo to be removed from the PhotoContainer
     * @return True if the photo was successfully removed, and false if it was not in the PhotoContainer
     */
    public boolean removePhoto(Photo p) {
        if (photos.contains(p)) {
            photos.remove(p);
            return true;
        } else
            return false;
    }

    /**
     * Checks the size of the ArrayList of photos in a PhotoContainer
     * 
     * @return The size of the ArrayList of photos
     */
    public int numPhotos() {
        return photos.size();
    }

    /**
     * Checks to see if two PhotoContainers have the same name and contain the same photos
     * 
     * @param o The passing object to be compared to the calling object
     * @return True if the two PhotoContainers are the same, and false if they are not equal or are null
     */
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (o instanceof Album) {
            Album other = (Album) o;
            return this.name.equals(other.name);
        } else
            return false;
    }

    /**
     * Converts an album into a String containing the album name and photos
     * 
     * @return A String containing the album name and HashSet of photos
     */
    public String toString() {
        return (this.name + ": " + this.photos);
    }

    /**
     * Converts the name of an PhotoContainer into a unique hashCode
     * 
     * @return The unique hashCode for the name of the PhotoContainer
     */
    public int hashCode() {
        return (this.name).hashCode();
    }

    /**
     * Gets all photos from the ArrayList of photos that have a rating greater than or equal to the input rating
     * 
     * @param rating The integer rating that all returned photo's ratings will be greater than or equal to
     * @return An ArrayList of photos with a rating greater than or equal to the input rating, or null if the rating is
     *         invalid
     */
    public ArrayList<Photo> getPhotos(int rating) {
        if (rating < 1 || rating > 5) {
            return null;
        }
        ArrayList<Photo> photoList = new ArrayList<Photo>();
        for (Photo p : photos) {
            if (p.getRating() >= rating) {
                photoList.add(p);
            }
        }
        return photoList;
    }

    /**
     * Gets all photos from the ArrayList of photos that were taken in the input year
     * 
     * @param year The integer year that all returned photos will have been taken in
     * @return An ArrayList of photos that were taken in the given year
     */
    public ArrayList<Photo> getPhotosInYear(int year) {
        if (0000 <= year && year <= 9999) {
            ArrayList<Photo> photoList = new ArrayList<Photo>();
            for (Photo p : this.photos) {
                if (DateLibrary.getYear(p.getDateTaken()) == year) {
                    photoList.add(p);
                }
            }
            return photoList;
        } else
            return null;
    }

    /**
     * Gets all photos from the ArrayList of photos that were taken in the input month and year
     * 
     * @param month The integer month that all returned photos will have been taken in
     * @param year  The integer year that all returned photos will have been taken in
     * @return An ArrayList of photos that were taken in the given month and year
     */
    public ArrayList<Photo> getPhotosInMonth(int month, int year) {
        if (1 <= month && month <= 12 && 0 <= year && year <= 9999) {
            ArrayList<Photo> photoList = new ArrayList<Photo>();
            for (Photo p : this.photos) {
                if (DateLibrary.getYear(p.getDateTaken()) == year && DateLibrary.getMonth(p.getDateTaken()) == month) {
                    photoList.add(p);
                }
            }
            return photoList;
        } else
            return null;
    }

    /**
     * Gets all photos from the ArrayList of photos that were taken between the two input dates
     * 
     * @param beginDate The String date that all returned photos will have been taken on or after
     * @param endDate   The String date that all returned photos will have been taken on or before
     * @return An ArrayList of photos that were taken between the given dates
     */
    public ArrayList<Photo> getPhotosBetween(String beginDate, String endDate) {
        if (DateLibrary.isValidDate(beginDate) && DateLibrary.isValidDate(endDate)
                && DateLibrary.compare(beginDate, endDate) <= 0) {
            ArrayList<Photo> photoList = new ArrayList<Photo>();
            for (Photo p : this.photos) {
                if (DateLibrary.compare(beginDate, p.getDateTaken()) <= 0
                        && DateLibrary.compare(p.getDateTaken(), endDate) <= 0) {
                    photoList.add(p);
                }
            }
            return photoList;
        } else
            return null;
    }

}
