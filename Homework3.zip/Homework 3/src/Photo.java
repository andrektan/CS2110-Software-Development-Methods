/**
 * Homework 3 Andre Tan, akt6pfg
 */

public class Photo implements Comparable<Photo> {
    /**
     * Holds the name of the file as a string.
     */
    private final String filename;

    /**
     * Holds the caption of the photo as a string.
     */
    private final String caption;

    /**
     * Holds the rating of the photo as an int, on a scale from 1-5.
     */
    private int rating;

    /**
     * Holds a string containing the date the photograph was taken
     */
    private final String dateTaken;

    /**
     * Assigns a filename and caption to a new photo, assigns a default rating of 1, and a default dateTaken of "1901-01-01"
     * 
     * @param filename The filename to be assigned to the photo
     * @param caption  The caption to be assigned to the photo
     */
    public Photo(String filename, String caption) {
        this.filename = filename;
        this.caption = caption;
        rating = 1;
        dateTaken = "1901-01-01";
    }

    /**
     * Assigns a filename, caption, rating, and dateTaken to a new photo. If the rating or dateTaken is not valid, assigns
     * default values of 1 or "1901-01-01" respectively
     * 
     * @param filename  The filename to be assigned to the photo
     * @param caption   The caption to be assigned to the photo
     * @param rating    The rating to be assigned to the photo
     * @param dateTaken The date the photo was taken to be assigned to the photo
     */
    public Photo(String filename, String caption, String dateTaken, int rating) {
        this.filename = filename;
        this.caption = caption;
        if (1 <= rating && rating <= 5) {
            this.rating = rating;
        } else
            this.rating = 1;
        if (DateLibrary.isValidDate(dateTaken)) {
            this.dateTaken = dateTaken;
        } else
            this.dateTaken = "1901-01-01";
    }

    /**
     * Getter for the filename of the photo
     * 
     * @return The photo filename
     */
    public String getFilename() {
        return this.filename;
    }

    /**
     * Getter for the caption of the photo
     * 
     * @return The photo caption
     */
    public String getCaption() {
        return this.caption;
    }

    /**
     * Getter for the rating of the photo
     * 
     * @return The photo rating
     */
    public int getRating() {
        return this.rating;
    }

    /**
     * Getter for the dateTaken of the photo
     * 
     * @return The date the photo was taken
     */
    public String getDateTaken() {
        return this.dateTaken;
    }

    /**
     * Sets the rating of a photo to the input rating and returns true if it is a valid number and returns false otherwise
     * 
     * @param The new rating to be assigned to a photo
     * @return Whether or not the rating has been changed to a valid number
     */
    public boolean setRating(int newRating) {
        if ((newRating != rating) && (1 <= newRating) && (newRating <= 5)) {
            this.rating = newRating;
            return true;
        } else
            return false;
    }

    /**
     * Compares the filename and caption of two photos and returns true if they are the same
     * 
     * @param o The photo that is the passing object to be compared to the casting one
     * @return Whether or not the passed object contains the same filename and caption as the casted one
     */
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (o instanceof Photo) {
            Photo p = (Photo) o;
            return ((this.filename.equals(p.filename)) && (this.caption.equals(p.caption)));
        } else
            return false;
    }

    /**
     * Converts a photo object to return a string with the filename and caption
     * 
     * @return The filename and caption
     */
    public String toString() {
        return ("Filename: " + this.filename + ", Caption: " + this.caption + ".");

    }

    /**
     * Converts the filename of a photo into a unique hashCode
     * 
     * @return The unique hashCode for the filename of the photo
     */
    public int hashCode() {
        return (this.filename).hashCode();
    }

    /**
     * Compares two photos by the date taken, then by caption if needed. Returns a negative number if the calling object
     * comes first, a positive number if the passing object comes first, and zero if the two are equal.
     */
    public int compareTo(Photo p) {
        int retVal = this.dateTaken.compareTo(p.getDateTaken());
        if (retVal != 0) {
            return retVal;
        } else
            return this.caption.compareTo(p.getCaption());
    }

    public static void main(String[] args) {
        Photo p1 = new Photo("New Years", "no cap");

        System.out.println(p1);
        System.out.println(p1.rating);

        p1.setRating(4);
        System.out.println(p1.rating);

        Photo p2 = new Photo("New Millenium", "Amazing", "2000-01-01", 4);
        System.out.println(p2);
        System.out.println(p2.rating);

        p2.setRating(2);
        System.out.println(p2.rating);
        System.out.println(p1.equals(p2));

        Photo p3 = new Photo("New Years Day", "Amazing", "2001-01-01", 3);
        System.out.println(p3);
        System.out.println(p2.equals(p3));

        System.out.println(p1.hashCode());
        System.out.println(p2.hashCode());
    }

}
