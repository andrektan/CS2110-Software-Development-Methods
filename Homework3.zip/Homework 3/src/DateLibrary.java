/**
 * Homework 3 Andre Tan, akt6pfg
 */

public class DateLibrary {

    /**
     * Check to see if a given string is in the valid format "YYYY-MM-DD" containing only digits and hyphens
     * 
     * @param date A String date in the format "YYYY-MM-DD"
     * @return True if the date is in the given format, and false if it is not
     */
    public static boolean isValidDateFormat(String date) {
        if ((date.length() == 10) && (date.charAt(4) == (char) 45) && (date.charAt(7) == (char) 45)) {
            if ("0123456789".contains(date.substring(0, 1)) && "0123456789".contains(date.substring(1, 2))) {
                if ("0123456789".contains(date.substring(2, 3)) && "0123456789".contains(date.substring(3, 4))) {
                    if ("0123456789".contains(date.substring(5, 6)) && "0123456789".contains(date.substring(6, 7))) {
                        if ("0123456789".contains(date.substring(8, 9)) && "0123456789".contains(date.substring(9))) {
                            return true;
                        } else
                            return false;
                    } else
                        return false;
                } else
                    return false;
            } else
                return false;
        } else
            return false;
    }

    /**
     * If the input date is in the valid format, return the year
     * 
     * @param date A String date in the format "YYYY-MM-DD"
     * @return The year of the given date
     */
    public static int getYear(String date) {
        if (isValidDateFormat(date) == true) {
            int year = Integer.parseInt(date.substring(0, 4));
            if (year > 0 && year <= 9999) {
                return year;
            }
        }
        return -1;
    }

    /**
     * If the input date is in the valid format,
     * 
     * @param date A String date in the format "YYYY-MM-DD"
     * @return The month of the given date
     */
    public static int getMonth(String date) {
        if (isValidDateFormat(date) == true) {
            int month = Integer.parseInt(date.substring(5, 7));
            if (month > 0 && month <= 12) {
                return month;
            }
        }
        return -1;
    }

    /**
     * If the input date is in the valid format,
     * 
     * @param date
     * @return The day of the given date
     */
    public static int getDay(String date) {
        if (isValidDateFormat(date) == true) {
            int day = Integer.parseInt(date.substring(8));
            if (day > 0 && day <= 31) {
                return day;
            }
        }
        return -1;
    }

    /**
     * Checks to see if the given year is a leap year
     * 
     * @param year The integer representing the year to be checked
     * @return True if the given year is a leap year, and false otherwise
     */
    public static boolean isLeapYear(int year) {
        if (year % 4 == 0) {
            if (year % 100 != 0) {
                return true;
            } else if (year % 100 == 0 && year % 400 == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks to see if a given date is a valid date
     * 
     * @param date A String date in the format "YYYY-MM-DD"
     * @return True if the date is valid, and false otherwise
     */
    public static boolean isValidDate(String date) {
        int year = getYear(date);
        int month = getMonth(date);
        int day = getDay(date);
        if (isValidDateFormat(date) == true && year != -1 && month != -1 && day != -1) {
            if (month == 2) {
                if (isLeapYear(year) == true && day <= 29) {
                    return true;
                } else if (day <= 28) {
                    return true;
                } else
                    return false;
            } else if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                if (day <= 31) {
                    return true;
                } else
                    return false;
            } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                if (day <= 30) {
                    return true;
                } else
                    return false;
            }
        }
        return false;
    }

    /**
     * Compare two dates and returns whether they are the same date or a number representing whichever one comes first
     * 
     * @param date1 The first String date in the format "YYYY-MM-DD"
     * @param date2 The second String date in the format "YYYY-MM-DD"
     * @return 0 if either date is not in the valid format or if they are the same, a positive number if date2 comes first,
     *         and a positive number date1 comes first
     */
    public static int compare(String date1, String date2) {
        if (isValidDate(date1) == false || isValidDate(date2) == false || date1 == date2) {
            return 0;
        }
        return date1.compareTo(date2);
    }

    public static void main(String[] args) {
        System.out.println(isValidDateFormat("2001-13-24"));
        System.out.println(isValidDateFormat("9999-1--31"));

        System.out.println(getYear("2001-12-24"));
        System.out.println(getYear("0000-13-31"));

        System.out.println(getMonth("2001-12-24"));
        System.out.println(getMonth("2001-13-24"));

        System.out.println(getDay("2001-12-24"));
        System.out.println(getDay("2001-02-32"));

        System.out.println(isLeapYear(2000));
        System.out.println(isLeapYear(2001));

        System.out.println(isValidDate("2001-12-24"));
        System.out.println(isValidDate("1000-02-29"));

        System.out.println(compare("2001-12-24", "2000-12-25"));
        System.out.println(compare("2000-12-24", "2001-12-25"));
    }
}
